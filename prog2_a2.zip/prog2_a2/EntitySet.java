package prog2_a2;
import java.util.ArrayList;


public class EntitySet {
    ArrayList<Entity> entityList;
    Entity entity;
    int numbOf=0;
    
    public EntitySet(){
        entity = new Entity();
        entityList = new ArrayList<>();
        
    }
    
    public void create(String entityTyp,int id, int x, int y){
        numbOf++;
        switch(entityTyp){
            case"BadPlant": entityList.add(id,new BadPlant(id,x,y));break;
            case"GoodBeast":entityList.add(id,new GoodBeast(id,x,y));break;
            case"GoodPlant":entityList.add(id,new GoodPlant(id,x,y));break;
            case"BadBeast":entityList.add(id,new BadBeast(id,x,y));break;
            case"MasterSquirrel":entityList.add(id,new MasterSquirrel(id,x,y));break;
            case"Wall":entityList.add(id,new Wall(id,x,y));
            case"GuidedMasterSquirrel":entityList.add(id,new GuidedMasterSquirrel(id,x,y));
        }
    }
    
    public void delete(int id){
        entityList.remove(id);
        numbOf--;
    }
    
    public String outputString(){
        return entityList.toString();
    }
    public void nextStepAll(){
        Object entArray = new Object[entityList.toArray().length];
        entArray = entityList.toArray();
        
        for(int i=0; i<=numbOf;i++){
           entArray[i].nextStep();
    }
    }
}