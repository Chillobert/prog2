package prog2_a2;

public class EntitySet {

    int numbOf=0;
    Entity[] entArray = new Entity[50];
    int idColl=0;
    
    public EntitySet(){      
    }
    
    public void add(String entityTyp,int id, int x, int y){
        switch(entityTyp){
            case"BadPlant": entArray[numbOf++] = new BadPlant(id,x,y);break;
            case"GoodBeast":entArray[numbOf++] = new GoodBeast(id,x,y);break;
            case"GoodPlant":entArray[numbOf++] = new GoodPlant(id,x,y);break;
            case"BadBeast":entArray[numbOf++] = new BadBeast(id,x,y);break;
            case"GuidedMasterSquirrel":entArray[numbOf++] = new GuidedMasterSquirrel(id,x,y);break;
            case"Wall":entArray[numbOf++] = new Wall(id,x,y);break;
        }
    }
    
    public void delete(int id){
        Entity[] copyArray = new Entity[50];
        int j=0;
        for(int i=0;i<entArray.length;i++){
            if(!(entArray[i].getId() == id)){
                copyArray[j] = entArray[i];
                j++;
            }
            for(int k=0;k<copyArray.length;k++)
                if(entArray[k]!=null)
                entArray[k]=copyArray[k];
        }
        numbOf--;
    }
    
    public int getLatestId(){
        return numbOf;
    }
    
    @Override
    public String toString(){
        String output="";
        for(int i=0;entArray[i]!=null;i++){
            output += entArray[i].toString()+"/n";
        }
        return(output);
    }

    public void nextStepAll(){
        for(int i=0;entArray[i]!=null;i++){
            entArray[i].nextStep();
             checkCollision(i);
                
            
        }
    }

    private void checkCollision(int ArrayPos){
        for(int i=0;entArray[i]!=null;i++){
            if(entArray[ArrayPos].loc.getPos()==entArray[i].loc.getPos()){
                mortalCombat(ArrayPos,i);
                return;
            }
        }
    }
    //equals methode(mit instanceof)?
    private void mortalCombat(int ArrayPos,int CollPos){
        if(entArray[ArrayPos] instanceof PlayerEntity){
            if(entArray[CollPos] instanceof GoodPlant){
                entArray[ArrayPos].updateEnergy(entArray[CollPos].getEnergy());
                //gelöschte Elemente als Int[] und nach der schleife in check delete aufrufen mit allen Elementen
                //und bei Update energy das element des Verlierers auf 0 setzen
            }
        }
    }
}