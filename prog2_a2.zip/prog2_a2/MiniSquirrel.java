package prog2_a2;

public class MiniSquirrel extends Entity{
	public char patron;

	public MiniSquirrel(int id, int energy, int x, int y, char patron) {
            super(id, energy, x, y);
            this.patron = patron;
	}

        @Override
        public void nextStep(){
            move(loc.randVect());
        }
        
        public String getEntity(){
            return "MiniSquirrel";
        }
}
