package prog2_a3;

import java.util.Arrays;

public class Board {
	
int length;
int width;
int amountGoodBeasts;
int amountBadBeasts;
int amountGoodPlants;
int amountBadPlants;
int amountWalls;
String[][] board;

	
	public Board(){
		BoardConfig config = new BoardConfig();
		this.length = config.getLength();
		this.width = config.getWidth();
		this.amountGoodBeasts = config.getAmountGoodBeasts();
		this.amountBadBeasts = config.getAmountBadBeasts();
		this.amountGoodPlants = config.getAmountGoodPlants();
		this.amountBadPlants = config.getAmountBadPlants();
		String[][] board = new String[config.length][config.width];
		fillBoard(2,3,2,2,2);
	};
	
	public void fillBoard(int amountGoodBeasts, int amountBadBeasts, int amountGoodPlants, int amountBadplants, int amountWalls){
		//testzwecke

	};
	
    public String toString(){
    		
    	return (Arrays.deepToString(board) + "\n");
    }

	
	
	
	

	public int getEntityCount() {
		int amount = 0;
		return amount;
		
	}
	
}
