package prog2_a3;

public class BoardConfig {
public int length = 40;
public int width = 20;
public int amountGoodBeasts = 2;
public int amountBadBeasts = 2;
public int amountGoodPlants = 2;
public int amountBadPlants = 2;
public int amountWalls = 2*length + 2*width;

	public int getLength(){
		return length;
	}
	public int getWidth(){
		return width;
	}
	public int getAmountGoodBeasts(){
		return amountGoodBeasts;
	}
	public int getAmountBadBeasts(){
		return amountBadBeasts;
	}
	public int getAmountGoodPlants(){
		return amountGoodPlants;
	}
	public int getAmountBadPlants(){
		return amountBadPlants;
	}
	public int getAmountWalls(){
		return amountWalls;
	}
	

	
	
}
