package prog2_a3;

public abstract class Game {

	public static void main(String []args){
		
	};

	public void run(){
			while(true){
				render();
				processInput();
				update();
			}
	}
		
		
//Darstellung des Spielzustand auf dem Ausgabemedium
	abstract void render();
	
//Verarbeitung von Benutzereingaben
	abstract void processInput();
	
//Ver�nderung des Spielzustandes -> Vorbereitung n�chster Render Vorgang	
	private void update() {}	
	
	
}


/*

	public static void main(String[] args){
		
			/*
            Boolean play=true;
            EntitySet ent = new EntitySet();

            while(play){
                ent.add("BadBeast", 0, 1, 2);
                ent.add("GoodBeast" ,1,2,3);
                ent.add("GoodPlant",2,3,4);
                ent.add("BadPlant",3,4,5);
                ent.add("GuidedMasterSquirrel",4,5,6);
                ent.add("Wall", 5, 6, 7);
                System.out.println(ent.toString());
                ent.nextStepAll();
                System.out.println(ent.toString());
                ent.delete(3);
                System.out.println(ent.toString());
                play=false;
            }
            */
            
		