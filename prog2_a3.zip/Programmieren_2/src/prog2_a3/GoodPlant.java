package prog2_a3;

public class GoodPlant extends Entity{
	
	public final static int energy = 100; 

	public GoodPlant(int id, int x, int y) {
		super(id, energy, x, y);
		// TODO Auto-generated constructor stub
	}

    @Override
    public void nextStep() {
    }

}
