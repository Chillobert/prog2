package prog2_a3;

public class State {
	public int highscore;
	
	Board Board = new Board();
	
	
}
